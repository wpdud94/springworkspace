package com.encore.pms.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.encore.pms.dto.Phone;
import com.encore.pms.dto.UserInfo;

@Repository
public class PhoneDaoImpl implements IPhoneDAO{
	@Autowired
	private SqlSession sqlSession;
	
	final String NS = "PhoneMapper.";
	
	public int insert(Phone phone) {
		sqlSession.insert(NS+"addPhone", phone);
		return 0;
	}

	public int delete(String num) {
		sqlSession.delete(NS+"deletePhone",num);
		return 0;
	}

	public Phone select(String num) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne(NS+"showPhone", num);
	}

	public List<Phone> select() {
		// TODO Auto-generated method stub
		return sqlSession.selectList(NS+"showAllPhone");
	}

	public UserInfo select(UserInfo user) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne(NS+"showUser", user);
	}
	
	
}
