package com.encore.pms.dao;

import java.util.List;

import com.encore.pms.dto.Phone;
import com.encore.pms.dto.UserInfo;

public interface IPhoneDAO {
	int insert(Phone phone);

	int delete(String num);

	Phone select(String num);

	List<Phone> select();

	UserInfo select(UserInfo user);
}
