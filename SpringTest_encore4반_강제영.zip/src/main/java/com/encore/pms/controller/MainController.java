package com.encore.pms.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.encore.pms.dto.Phone;
import com.encore.pms.dto.UserInfo;
import com.encore.pms.service.IPhoneService;

@Controller
public class MainController {	
	@Autowired
	private IPhoneService iPhoneService;
	
	@RequestMapping("register.do")
	public String resgister(String num, String model, String price, String vcode, Model m){
		try {
			int iprice = Integer.parseInt(price);
			iPhoneService.insert(new Phone(num, model, iprice, vcode));
			return "register_ok";
		}catch(Exception e) {
			m.addAttribute("msg","등록");
			return "Error";
		}
	}
	
	@RequestMapping("searchAllPhones.do")
	public String searchAllPhones(Model model) {
		try {
			List<Phone> list = iPhoneService.select();
			model.addAttribute("list", list);
			System.out.println(list);
			return "PhoneList";
		}catch(Exception e) {
			model.addAttribute("msg","조회");
			return "Error";
		}
	}
	
	@RequestMapping("searchPhone.do")
	public String searchPhone(String num, Model model) {
		try {
			Phone vo = iPhoneService.select(num);
			model.addAttribute("vo", vo);
			System.out.println(vo);
			return "PhoneView";
		}catch(Exception e) {
			model.addAttribute("msg","조회");
			return "Error";
		}
	}
	
	@RequestMapping("delete.do")
	public String delete(String[] list, Model model) {
		try {
			for(String a : list) {
				iPhoneService.delete(a);
			}
			List<Phone> plist = iPhoneService.select();
			model.addAttribute("list", plist);
			return "PhoneList";
		}catch(Exception e) {
			model.addAttribute("msg","삭제");
			return "Error";
		}
	}
	
	@RequestMapping("login.do")
	public ModelAndView login(String id, String pw, HttpServletRequest request) {
		try {
			UserInfo user = new UserInfo(id, pw);
			UserInfo loginUser = iPhoneService.select(user);
			if(loginUser==null) {
				return new ModelAndView("index","msg","아이디와 비밀번호를 확인해주세요"); 
			}
			request.getSession().setAttribute("loginUser", loginUser);
			return new ModelAndView("redirect:/index.jsp");
		}catch(Exception e) {
			return new ModelAndView("Error","msg","로그인");
		}
	}
	
	@RequestMapping("logout.do")
	public ModelAndView logout(HttpServletRequest request) {
		try {
			request.getSession().invalidate();
			return new ModelAndView("redirect:/index.jsp");
		}catch(Exception e) {
			return new ModelAndView("Error","msg","로그아웃");
		}
	}
}
