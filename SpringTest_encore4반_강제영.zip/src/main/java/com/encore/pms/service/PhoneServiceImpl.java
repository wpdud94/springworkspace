package com.encore.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.encore.pms.dao.IPhoneDAO;
import com.encore.pms.dto.Phone;
import com.encore.pms.dto.UserInfo;



@Service
public class PhoneServiceImpl implements IPhoneService{
	@Autowired
	private IPhoneDAO iPhoneDAO;
	
	public int insert(Phone phone) {
		iPhoneDAO.insert(phone);
		return 0;
	}

	public int delete(String num) {
		iPhoneDAO.delete(num);
		return 0;
	}

	public Phone select(String num) {
		
		return iPhoneDAO.select(num);
	}

	public List<Phone> select() {
		
		return iPhoneDAO.select();
	}

	public UserInfo select(UserInfo user) {
		// TODO Auto-generated method stub
		return iPhoneDAO.select(user);
	}

	

}
