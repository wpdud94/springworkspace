package com.encore.pms.test;

import java.io.IOException;
import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.encore.pms.dto.Phone;

public class MyBatisTest {
	@Test
	public void unit() throws IOException {
		Reader r = Resources.getResourceAsReader("spring/SqlMapConfig.xml");
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(r);
		SqlSession session = factory.openSession();
		
		String NS = "PhoneMapper.";
		
		//addPhone
		
		/*
		 * session.insert(NS+"addPhone", new Phone("S105", "겔러시S10", 1000000, "10"));
		 * session.commit();
		 */
		 
		// showAllPhone
		List<Phone> list =session.selectList(NS+"showAllPhone");
		for(Phone p : list) System.out.println(p);
		//showPhone
		session.selectOne(NS+"showPhone", "S105");
		//deletePhone
		session.delete(NS+"deletePhone","S105");
		session.commit();
		//showUser
		System.out.println(session.selectOne(NS+"showUser", "admin"));
	}
}
